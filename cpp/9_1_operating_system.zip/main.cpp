#include "main.h"
void  display(struct pcb *p){
	fprintf(pFile,"name    cputime    needtime    priority    state\n");
	while(p){
		fprintf(pFile,"%s", p->name);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d", p->cputime);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d", p->needtime);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d", p->priority);
		fprintf(pFile,"        ");
		switch(p->process){
			case ready:
				fprintf(pFile,"ready\n");
				break;
			case execute:
				fprintf(pFile,"execute\n");
				break;
			case block:
				fprintf(pFile,"block\n");
				break;
			case finish:
				fprintf(pFile,"finish\n");
				break;
		}
		p=p->next;
	}
}

int process_finish(struct pcb *q){         /*进程是否结束，当还有进程没有结束时返回0*/
	int bl=1;
	while(bl&&q){
		bl=bl&&q->needtime==0;
		q=q->next;
	}
	return bl;
}

void cpuexe(struct pcb *q){
	struct pcb *t=q;
	int max_priority=0;
	while(q){
		if (q->process!=finish){
			q->process=ready;
			if(q->needtime==0){
				q->process=finish;
			}
		}
		if(max_priority<q->priority&&q->process!=finish){
			max_priority=q->priority;
			t=q;
		}
		q=q->next;
	}
	if(t->needtime!=0){
		t->priority-=3;
		t->needtime--;
		t->process=execute;
		t->cputime++;
	}
}
void delay(int ms)
{
    ms*=1000000;
    while(ms--);
}
void priority_cal(){     /*优先数调度*/
	struct pcb * p;
	int cpu =0;
	p=get_process();
	while(!process_finish(p)){
		cpu++;
		fprintf(pFile, "cputime:%d\n" ,cpu);
		cpuexe(p);
		display(p);
		delay(5);
	}
	fprintf(pFile,"All processes have finished,press any key to exit");
}

void display_menu(){
	fprintf(pFile,"CHOOSE THE ALGORITHM:\n" );
	fprintf(pFile,"1 PRIORITY\n" );
	fprintf(pFile,"2 ROUNDROBIN\n" );
	fprintf(pFile,"3 EXIT\n" );
}
struct pcb * get_process_round(){       /*轮转进程建立*/
	struct pcb *q;//用于修改当前值
	struct pcb *t;//用于链表中间替换
	struct pcb *p;//用于保存链尾
	int i=0;
	fprintf(pFile,"input name and time,please input 3 processes\n");

	while (i<P_NUM){
		q=(struct pcb *)malloc(sizeof(struct pcb));
		scanf( "%s", &(q->name));
		scanf( "%d", &(q->needtime));
		q->cputime=0;
		q->round=0;
		q->count=0;
		q->process=ready;
		q->next=NULL;
		if (i==0){
			p=q;
			t=q;
		}
		else{
			t->next=q;
			t=q;
		}
		i++;
	}  /*while*/
	return p;
}

void cpu_round(struct pcb *q){   /*处理机轮转*/
	q->cputime+=2;
	q->needtime-=2;
	if(q->needtime<0) {
		q->needtime=0;
	}
	q->count++;
	q->round++;
	q->process=execute;

}

struct pcb * get_next(struct pcb * k, struct pcb * head){    /*返回没有结束的进程*/
	struct pcb * t;
	t=k;
	do{
	 t=t->next;
	}while (t && t->process==finish);
	if(t==NULL){
		t=head;
		while (t->next!=k && t->process==finish){
			t=t->next;
		}
	}
	return t;
}

void set_state(struct pcb *p){
	while(p){
		if (p->needtime==0){
			p->process=finish;

		}
		if (p->process==execute){
			p->process=ready;
		}
		p=p->next;
	}
}

void display_round(struct pcb *p){
	fprintf(pFile,"NAME  CPUTIME  NEEDTIME  COUNT  ROUND  STATE\n");
	while(p){
		fprintf(pFile,"%s",p->name);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d",p->cputime);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d",p->needtime);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d",p->count);
		fprintf(pFile,"        ");
		fprintf(pFile,"%d",p->round);
		fprintf(pFile,"        ");
		switch(p->process){
				case ready:
				fprintf(pFile,"ready\n");
				break;
			case execute:
				fprintf(pFile,"execute\n");
				break;
			case finish:
				fprintf(pFile,"finish\n");
				break;
		}
		p=p->next;
	}
}

void round_cal(){         /*循环轮转调度*/
	struct pcb * p;
	struct pcb * r;
	int cpu=0;
	p=get_process_round();
	r=p;
	while(!process_finish(p)){
		cpu+=2;
		cpu_round(r);
		r=get_next(r,p);
		fprintf(pFile,"cpu %d\n", cpu );
		display_round(p);
		set_state(p);
		delay(5);
	}
fprintf(pFile,"All processes have finished,press any key to exit");
}
//fprintf (pFile, "Name %d [%-10.10s]\n",n,name);
/* 主程序 */

int main(){// 没有free
    freopen("data_1.txt","r",stdin);
    pFile = fopen ("output.txt","w");
	int user_input;
	display_menu();
	scanf("%d",&user_input);
	switch(user_input){
			case 1:priority_cal();break;
			case 2:round_cal();break;
			case 3:break;
			default:
			display_menu();
			scanf("%d",&user_input);
			break;
	}
	fclose (pFile);
	exit(0);
	}
