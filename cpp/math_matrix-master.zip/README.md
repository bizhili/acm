# math_matrix
C语言矩阵库，在linux下测试
