1.The recursive of function:
description:to use self in a function;
application:
1)you don't the times of cycle;
2)arrangement ways
3)problem of Hanoi Tower
4)the recurrsive travesal of a tree
warning:
must exist a exit return
eg:
if(delete_value(value))
		return 1;

2.Binary Search
description:need a ordered sequence;
most terrobile time complexity:
log2N
warning:to conside odd or not odd 


